const controller = new NotesController($('.container'));
