const tabset = new Tabset(document.getElementById('container'));
const accordion = new Accordion(document.getElementById('accordion'), {
    collapseOthers: false,
});
