module.exports = (...args) => args.reduce((acc, a) => acc + a);
