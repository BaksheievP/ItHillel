// const calculator = require('./calculator');
// import lll from './calculator/index.js';

// console.log(add(20, 3)); // 5
// console.log(sub(20, 3)); // 17
// lll();
// console.log(calculator.mult(20, 3)); // 60
// console.log(calculator.div(21, 3)); // 7
